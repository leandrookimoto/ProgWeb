<?php
/**
 * Application configuration shared by all applications unit tests
 */
return [

];